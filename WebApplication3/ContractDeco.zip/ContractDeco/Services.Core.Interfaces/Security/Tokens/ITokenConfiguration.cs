﻿namespace Services.Core.Interfaces.Security.Tokens
{
	public interface ITokenConfiguration
	{
		#region properties 

		string Audience { get; }
		string Issuer { get; }
		string Secret { get; }
		string UserName { get; }
		string Password { get; }
		int ExpirationMinutes { get; }

		#endregion

	}
}