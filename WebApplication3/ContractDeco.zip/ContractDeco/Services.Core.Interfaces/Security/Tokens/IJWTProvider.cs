﻿using Microsoft.Extensions.DependencyInjection;

namespace Services.Core.Interfaces.Security.Tokens
{
	public interface IJWTProvider
    {
		#region properties

		//ITokenConfiguration Configuration { get; }

		#endregion

		#region methods

		void AddAuthentication(IServiceCollection services);
		//string GetToken(string name);
		string GetToken(string credentials);

		#endregion

	}
}
