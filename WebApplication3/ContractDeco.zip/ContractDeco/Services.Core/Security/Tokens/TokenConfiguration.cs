﻿namespace Services.Core.Security.Tokens
{
	internal class TokenConfiguration// : ITokenConfiguration
	{
		//#region fields

		//private static string sectionNameLiteral = "Tokens";
		//private static string audienceLiteral = "Audience";
		//private static string issuerLiteral = "Issuer";
		//private static string secretLiteral = "Secret";
		//private static string userNameLiteral = "UserName";
		//private static string passwordLiteral = "Password";
		//private static string expirationMinutesLiteral = "ExpirationMinutes";

		//#endregion

		#region properties 

		public string Audience { get; private set; }
		public string Issuer { get; private set; }
		public string Secret { get; private set; }
		public string UserName { get; private set; }
		public string Password { get; private set; }
		public int ExpirationMinutes { get; private set; }

		#endregion

		#region constructors

		private TokenConfiguration()
		{
		}

		//public TokenConfiguration(IConfiguration configuration)
		//{
		//	Audience = configuration[$"{sectionNameLiteral}:{audienceLiteral}"];
		//	Issuer = configuration[$"{sectionNameLiteral}:{issuerLiteral}"];
		//	Secret = configuration[$"{sectionNameLiteral}:{secretLiteral}"];
		//	UserName = configuration[$"{sectionNameLiteral}:{userNameLiteral}"];
		//	Password = configuration[$"{sectionNameLiteral}:{passwordLiteral}"];
		//	ExpirationMinutes = int.Parse(configuration[$"{sectionNameLiteral}:{expirationMinutesLiteral}"]);
		//}

		#endregion

		#region public methods

		public static TokenConfiguration ForIssuer(string name)
		{
			if (name == "contractdeco.com")
			{
				return new TokenConfiguration
				{
					Audience = "contractdeco.com",
					Issuer = "contractdeco.com",
					Secret = "0^iOm+qZF&qL=of;9Wrb'_+2K^h__%e]G$!%1N3M'Wu6Smb1G:knsmQNSW%/@2xB",
					UserName = "contractdeco",
					Password = "contractdeco",
					ExpirationMinutes = 10
				};
			}

			return null;
		}

		#endregion

	}
}