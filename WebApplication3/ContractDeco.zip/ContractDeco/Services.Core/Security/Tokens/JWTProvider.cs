﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Services.Core.Interfaces.Security.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Services.Core.Security.Tokens
{
	public class JWTProvider : IJWTProvider
	{
		#region fields

		private TokenConfiguration configuration;

		#endregion

		#region properties

		//public ITokenConfiguration Configuration { get; private set; }

		#endregion

		#region constructors

		//public JWTProvider(ITokenConfiguration configuration)
		public JWTProvider(string name)
		{
			//Configuration = configuration;
			configuration = TokenConfiguration.ForIssuer(name);
		}

		#endregion

		#region public methods

		public void AddAuthentication(IServiceCollection services)
		{
			services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
			{
				options.TokenValidationParameters = new TokenValidationParameters
				{
					ValidateIssuer = true,
					ValidIssuer = configuration.Issuer,
					ValidateAudience = true,
					ValidAudience = configuration.Audience,
					ValidateIssuerSigningKey = true,
					IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration.Secret)),
					ValidateLifetime = true
				};
			});
		}

		public string GetToken(string credentials)
		{
			var credentialParts = Encoding.UTF8.GetString(Convert.FromBase64String(credentials)).Split(':');
			//check for value user/password
			if (credentialParts[0] != configuration.UserName || credentialParts[1] != configuration.Password)
				return null;

			var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration.Secret));
			var signingCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);
			var tokenString = new JwtSecurityToken(
				issuer: configuration.Issuer,
				audience: configuration.Audience,
				expires: DateTime.Now.AddMinutes(configuration.ExpirationMinutes),
				claims: new[] { new Claim(ClaimTypes.Name, credentialParts[0]) },
				signingCredentials: signingCredentials
				);
			var token = new JwtSecurityTokenHandler().WriteToken(tokenString);

			return token;
		}

		#endregion

	}
}
