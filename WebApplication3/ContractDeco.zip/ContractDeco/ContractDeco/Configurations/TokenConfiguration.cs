﻿using Microsoft.Extensions.Configuration;
using Services.Core.Interfaces;

namespace ContractDeco.Configurations
{
	public class  TokenConfiguration: ITokenConfiguration
	{
		#region fields

		private static string sectionNameLiteral = "Tokens";
		private static string audienceLiteral = "Audience";
		private static string issuerLiteral = "Issuer";
		private static string secretLiteral = "Secret";
		private static string userNameLiteral = "UserName";
		private static string passwordLiteral = "Password";

		#endregion

		#region properties 

		public string Audience { get; private set; }
		public string Issuer { get; private set; }
		public string Secret { get; private set; }
		public string UserName { get; private set; }
		public string Password { get; private set; }

		#endregion

		#region constructors

		public TokenConfiguration(IConfiguration configuration)
		{
			Audience = configuration[$"{sectionNameLiteral}:{audienceLiteral}"];
			Issuer = configuration[$"{sectionNameLiteral}:{issuerLiteral}"];
			Secret = configuration[$"{sectionNameLiteral}:{secretLiteral}"];
			UserName = configuration[$"{sectionNameLiteral}:{userNameLiteral}"];
			Password = configuration[$"{sectionNameLiteral}:{passwordLiteral}"];
		}

		#endregion

	}
}
