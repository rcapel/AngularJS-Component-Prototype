﻿using System.ComponentModel.DataAnnotations;

namespace ContractDeco.Models
{
	public class Shipping
	{
		[Required]
		public string OrderId { get; set; }
		[Required]
		public decimal Subtotal { get; set; }
		[Required]
		public decimal ActualShipping { get; set; }
		[Required]
		public decimal Total { get; set; }
		[Required]
		public string TrackingNumber { get; set; }
	}

}
/*
{
	"orderId": "order-12345",
    "subtotal": 383.1,
    "actualShipping": 25.73,
    "total": 408.83,
	"trackingNumber": "ABC123etc"
}
*/
