﻿using System.ComponentModel.DataAnnotations;

namespace ContractDeco.Models
{
	public class DesignIds
    {
		[Required]
		public string TemporaryId { get; set; }
		[Required]
		public string DesignId { get; set; }
	}
}

