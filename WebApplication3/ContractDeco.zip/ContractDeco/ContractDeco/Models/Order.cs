﻿using System.ComponentModel.DataAnnotations;

namespace ContractDeco.Models
{
	public enum ShippingMethods { UPS, FEDEX, USPS }

	public class Order
	{
		[Required]
		public string DesignId { get; set; }
		[Required]
		public string OrderId { get; set; }
		[Required]
		public int Quantity { get; set; }
		[Required]
		public string ShipToAddress { get; set; }
		[Required]
		[EnumDataType(typeof(ShippingMethods))]
		public ShippingMethods ShippingMethod { get; set; }
		[Required]
		public decimal Subtotal { get; set; }
		[Required]
		public decimal EstimatedShipping { get; set; }
		[Required]
		public decimal Total { get; set; }
	}

}
/*
{
	"designId": "design-12345",
    "orderId": "order-12345",
	"quantity": "12",
	"shipToAddress": "address, etc.",
	"shippingMethod": "UPS",
    "subtotal": 383.1,
    "estimatedShipping": 24.87,
    "total": 407.97
}
*/
