﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ContractDeco.Models
{
	public class Artwork
	{
		[Required]
		public string CustomerNumber { get; set; }
		[Required]
		public IEnumerable<ArtworkItem> Items { get; set; }
	}

	public class ArtworkItem
	{
		[Required]
		public string Number { get; set; }
		[Required]
		public int Quantity { get; set; }
		[Required]
		public IEnumerable<ArtworkImage> Images { get; set; }
	}

	public class ArtworkImage
	{
		[Required]
		public string FileName { get; set; }
		[Required]
		public string PlacementCode { get; set; }
		[Required]
		public IEnumerable<ArtworkColor> Colors { get; set; }
	}

	public class ArtworkColor
	{
		[Required]
		public string Number { get; set; }
		[Required]
		public int ThreadChart { get; set; }
		[Required]
		public int ThreadStop { get; set; }
	}

}
/*
{
	"customerNumber": "customer123",
	"items": [
	{
		"number": "12345XYZ",
		"quantity": 25,
		"images": [
		{
			"fileName": "APR5271_layout_A.png",
			"placementCode": "LC",
			"colors": [
			{
				"number": "03712",
				"threadChart": "12",
				"threadStop": "1"
			},
			{
				"number": "05721",
				"threadChart": "7",
				"threadStop": "1"
			}
			]
		}
		]
	}
	]
}
*/
