﻿using ContractDeco.Configuration;
using ContractDeco.Configuration.Interfaces;
using ContractDeco.Services;
using ContractDeco.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Services.Core.Interfaces.Security.Tokens;
using Services.Core.Security.Tokens;

namespace ContractDeco
{
	public class Startup
	{
		#region properties

		public IConfiguration Configuration { get; }

		#endregion

		#region constructors

		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		#endregion

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			//ITokenConfiguration tokenConfiguration = new TokenConfiguration(Configuration);
			//IJWTProvider jwtProvider = new JWTProvider(Configuration.tokenConfiguration);//using "var" instead of the interface type causes DI to fail
			IAppSettings appSettings = new AppSettings(Configuration);
			IJWTProvider jwtProvider = new JWTProvider(appSettings.JwtIssuer);//using "var" instead of the interface type causes DI to fail

			services.AddSingleton(Configuration);
			//services.AddSingleton(tokenConfiguration);
			//services.AddSingleton<ITokenConfiguration, TokenConfiguration>();
			services.AddSingleton(jwtProvider);
			//services.AddSingleton<IJWTProvider, JWTProvider>();
			//services.AddSingleton<ITestConfiguration, TestConfiguration>();
			services.AddTransient<IWorkflowService, RabbitMQService>();

			jwtProvider.AddAuthentication(services);
			//services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
			//{
			//	options.TokenValidationParameters = new TokenValidationParameters
			//	{
			//		ValidateIssuer = true,
			//		ValidIssuer = tokenConfiguration.Issuer,
			//		ValidateAudience = true,
			//		ValidAudience = tokenConfiguration.Audience,
			//		ValidateIssuerSigningKey = true,
			//		IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenConfiguration.Secret)),
			//		ValidateLifetime = true
			//	};
			//});

			//services.AddCors();
			services.AddCors(options =>
			{
				options.AddPolicy("Any", policyBuilder =>
				{
					policyBuilder
						.AllowAnyHeader()
						.AllowAnyMethod()
						.AllowAnyOrigin();
				});
			});

			services.AddMvc().
				AddXmlDataContractSerializerFormatters();
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}

			app.UseAuthentication();

			//app.UseCors(policyBuilder =>
			//{
			//	policyBuilder
			//		.AllowAnyHeader()
			//		.AllowAnyMethod()
			//		.AllowAnyOrigin();
			//});

			app.UseMvc();
		}
	}
}
