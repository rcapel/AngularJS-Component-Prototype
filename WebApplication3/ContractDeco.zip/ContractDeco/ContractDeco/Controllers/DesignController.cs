﻿using ContractDeco.Models;
using ContractDeco.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContractDeco.Controllers
{
	[Authorize]
	[Route("api/[controller]")]
    public class DesignController : ControllerBase
    {
		#region fields

		private readonly IWorkflowService workflowService;

		#endregion

		#region constructors

		public DesignController(IWorkflowService workflowService)
		{
			this.workflowService = workflowService;
		}

		#endregion

		#region public methods

		// POST api/design
		[HttpPost]
		[Consumes("application/json")]
		[Produces("application/json")]
		[ProducesResponseType(200, Type = typeof(DesignIds))]
		[ProducesResponseType(400)]
		public IActionResult Post([FromBody]DesignIds designIds)
		{
			if (!ModelState.IsValid)
				return BadRequest(ModelState);

			workflowService.HandleRequest(designIds, "hello");

			return Ok(designIds);
		}

		#endregion

	}
}
