﻿using ContractDeco.Models;
using ContractDeco.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContractDeco.Controllers
{
	[Authorize]
	[Route("api/[controller]")]
	public class OrderApprovedController : Controller
	{
		#region fields

		private readonly IWorkflowService workflowService;

		#endregion

		#region constructors

		public OrderApprovedController(IWorkflowService workflowService)
		{
			this.workflowService = workflowService;
		}

		#endregion

		#region public methods

		// POST api/order
		[HttpPost]
		[Consumes("application/json")]
		[Produces("application/json")]
		[ProducesResponseType(200, Type = typeof(Order))]
		[ProducesResponseType(400)]
		public IActionResult Post([FromBody]Order order)
		{
			if (!ModelState.IsValid)
				return BadRequest(ModelState);

			return Ok(order);
		}

		#endregion

	}
}
