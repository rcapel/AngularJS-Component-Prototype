﻿using ContractDeco.Models;
using ContractDeco.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContractDeco.Controllers
{
	[Authorize]
	[Route("api/[controller]")]
	public class ArtworkController : Controller
	{
		#region fields

		private readonly IWorkflowService workflowService;

		#endregion

		#region constructors

		public ArtworkController(IWorkflowService workflowService)
		{
			this.workflowService = workflowService;
		}

		#endregion

		#region public methods

		// POST api/design
		[HttpPost]
		[ProducesResponseType(200, Type = typeof(Artwork))]
		[ProducesResponseType(400)]
		public IActionResult Post([FromBody]Artwork artwork)
		{
			if (!ModelState.IsValid)
				return BadRequest(ModelState);

			workflowService.HandleRequest(artwork, "hello");

			return Ok(artwork);
		}

		#endregion

	}
}