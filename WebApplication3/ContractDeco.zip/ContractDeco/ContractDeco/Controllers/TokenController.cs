﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Services.Core.Interfaces.Security.Tokens;
using System;
using System.Text;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ContractDeco.Controllers
{
	[EnableCors("Any")]
	[Route("api/[controller]")]
	public class TokenController : Controller
	{
		#region fields

		private readonly IJWTProvider jwtProvider;

		#endregion

		#region constructors

		public TokenController(IJWTProvider jwtProvider)
		{
			this.jwtProvider = jwtProvider;
		}

		#endregion

		// GET: api/values
		[HttpGet]
		[ProducesResponseType(200, Type = typeof(string))]
		[ProducesResponseType(400)]
		public IActionResult Get([FromHeader(Name = "Authorization")] string authorizationHeader)
		{
			if (authorizationHeader == null || !authorizationHeader.StartsWith("Basic "))
				return BadRequest("No credentials");

			//var credentials = Encoding.UTF8.GetString(Convert.FromBase64String(authorizationHeader.Substring(5).Trim())).Split(':');
			////check for value user/password
			//if (credentials[0] != jwtProvider.Configuration.UserName || credentials[1] != jwtProvider.Configuration.Password)
			//	return BadRequest("Invalid credentials");

			//var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration.Secret));
			//var signingCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);
			//var tokenString = new JwtSecurityToken(
			//	issuer: configuration.Issuer,
			//	audience: configuration.Audience,
			//	expires: DateTime.Now.AddMinutes(10),
			//	claims: new[] { new Claim(ClaimTypes.Name, credentials[0]) },
			//	signingCredentials: signingCredentials
			//	);
			//var token = new JwtSecurityTokenHandler().WriteToken(tokenString);

			//var token = jwtProvider.GetToken(credentials[0]);
			var token = jwtProvider.GetToken(authorizationHeader.Substring(5).Trim());

			string xxx = GetARandomSecret();
			return Ok(token);
		}

		private string GetARandomSecret()
		{
			var start = 33;
			var end = 126;
			var random = new Random();
			int[] numbers = new int[512 / 8];
			var builder = new StringBuilder();
			for (int i = 0; i < 512 / 8; i++)
			{
				var number = random.Next(start, end);
				builder.Append((char)number);
			}
			return builder.ToString();
		}

	}
}
