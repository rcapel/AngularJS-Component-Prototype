﻿using ContractDeco.Configuration.Interfaces;
using Microsoft.Extensions.Configuration;

namespace ContractDeco.Configuration
{
	public class AppSettings : IAppSettings
	{
		#region fields

		private static string sectionNameLiteral = "Tokens";
		private static string jwtIssuer = "JwtIssuer";

		#endregion

		#region properties 

		public string JwtIssuer { get; private set; }

		#endregion

		#region constructors

		public AppSettings(IConfiguration configuration)
		{
			JwtIssuer = configuration[$"{sectionNameLiteral}:{jwtIssuer}"];
		}

		#endregion

	}
}
