﻿namespace ContractDeco.Configuration.Interfaces
{
	public interface IAppSettings
	{
		#region properties 

		string JwtIssuer { get; }

		#endregion

	}
}
