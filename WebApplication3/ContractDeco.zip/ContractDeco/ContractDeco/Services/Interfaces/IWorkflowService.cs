﻿namespace ContractDeco.Services.Interfaces
{
	public interface IWorkflowService
	{
		#region public methods

		void HandleRequest(object anObject, string queueName);

		#endregion

	}
}
