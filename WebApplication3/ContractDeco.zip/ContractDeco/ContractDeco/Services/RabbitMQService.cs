﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using ContractDeco.Services.Interfaces;
using System;
using System.Text;

namespace ContractDeco.Services
{
	public class RabbitMQService : IWorkflowService
	{
		#region public methods

		public void HandleRequest(object anObject, string queueName)
		{
			//try
			//{
			//	var factory = new ConnectionFactory { HostName = "localhost" };
			//	using (var connection = factory.CreateConnection())
			//	using (var channel = connection.CreateModel())
			//	{
			//		string serializedObject = JsonConvert.SerializeObject(anObject);
			//		var body = Encoding.UTF8.GetBytes(serializedObject);

			//		channel.QueueDeclare(queue: queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);
			//		channel.BasicPublish(exchange: "", routingKey: queueName, basicProperties: null, body: body);
			//	}
			//}
			//catch (Exception ex)
			//{
			//}
		}

		#endregion

	}
}
